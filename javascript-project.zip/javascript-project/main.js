// 1. Кәмелеттік жас
let age = 20;
if (age >= 18) {
    console.log("Кіруге рұқсат");
} else {
    console.log("Кіруге тыйым салынады");
}
 
// 2. Емтиханнан өтті ме?
let score = 65;
if (score >= 50) {
    console.log("Емтиханнан өтті");
} else {
    console.log("Қайта тапсыру қажет");
}
 
// 3. Оң, теріс немесе нөл
let number = 5;
if (number > 0) {
    console.log("Оң сан");
} else if (number < 0) {
    console.log("Теріс сан");
} else {
    console.log("Нөл");
}
 
// 4. Студенттің бағасы
score = 85;
if (score >= 90) {
    console.log("Өте жақсы");
} else if (score >= 70) {
    console.log("Жақсы");
} else if (score >= 50) {
    console.log("Қанағаттанарлық");
} else {
    console.log("Қайта тапсыру қажет");
}
 
// 5. Ауа температурасы
let temperature = 15;
if (temperature < 0) {
    console.log("Суық");
} else if (temperature <= 20) {
    console.log("Салқын");
} else {
    console.log("Жылы");
}
 
// 6. Жұп немесе тақ сан
number = 7;
if (number % 2 == 0) {
    console.log("Жұп сан");
} else {
    console.log("Тақ сан");
}
 
// 7. Бағдаршам
let color = "red";
if (color == "red") {
    console.log("Тоқта");
} else if (color == "yellow") {
    console.log("Дайындал");
} else if (color == "green") {
    console.log("Жүр");
}
 
// 8. Дүкендегі жеңілдік
let price = 25000;
if (price >= 20000) {
    price = price - price * 0.1;
}
console.log(price);
 
// 9. Жүйеге кіру
let login = "admin";
let password = "1234";
if (login == "admin" && password == "1234") {
    console.log("Қош келдіңіз!");
} else {
    console.log("Логин немесе құпиясөз қате");
}
 
// 10. Ақылды колледж
let hasCard = true;
let isStudent = true;
if (isStudent && hasCard) {
    console.log("Кіруге рұқсат");
} else {
    console.log("Әкімшілікке жүгініңіз");
}
